package com.springboot.thymeleaf.thymeleafapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafappApplication.class, args);
	}

}
