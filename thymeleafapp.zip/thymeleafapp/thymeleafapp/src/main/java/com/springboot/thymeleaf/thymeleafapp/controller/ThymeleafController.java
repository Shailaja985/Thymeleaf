package com.springboot.thymeleaf.thymeleafapp.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ThymeleafController {
	
	@RequestMapping("/hello")
	public String hello(Model model){
		model.addAttribute("theDate", new java.util.Date());
		return "helloworld";
	}
	
	
}
